const express = require('express');
const session = require('express-session');
const bodyParser = require('body-parser');
const cors = require('cors');
const path = require('path');
const fs = require('fs');
const Docker = require('dockerode');
const bcrypt = require('bcryptjs');

const app = express();
const docker = new Docker({ socketPath: '/var/run/docker.sock' });
const PORT = process.env.PORT || 3000;

const DATA_DIR = path.join(__dirname, '..', 'data');
const USERS_FILE = path.join(DATA_DIR, 'users.json');
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
if (!fs.existsSync(USERS_FILE)) fs.writeFileSync(USERS_FILE, JSON.stringify([]));

// ---------- helpers ----------
function loadUsers() {
  return JSON.parse(fs.readFileSync(USERS_FILE, 'utf8'));
}
function saveUsers(users) {
  fs.writeFileSync(USERS_FILE, JSON.stringify(users, null, 2));
}

async function pullImageIfNeeded(image) {
  const images = await docker.listImages();
  const exists = images.some(i => (i.RepoTags || []).includes(image));
  if (!exists) {
    console.log(`Pulling image ${image} ...`);
    await new Promise((resolve, reject) => {
      docker.pull(image, (err, stream) => {
        if (err) return reject(err);
        docker.modem.followProgress(stream, (err2, res) =>
          err2 ? reject(err2) : resolve(res));
      });
    });
    console.log(`Image ${image} pulled.`);
  }
}

async function containerInfo(c) {
  const container = docker.getContainer(c.Id);
  const info = await container.inspect();
  return {
    id: c.Id,
    name: c.Names[0].replace(/^\//, ''),
    image: c.Image,
    status: info.State.Status,
    running: info.State.Running,
    created: c.Created,
    ports: c.Ports,
    labels: c.Labels || {}
  };
}

// ---------- middleware ----------
app.use(cors());
app.use(bodyParser.json());
app.use(session({
  secret: 'mc-panel-secret-change-me',
  resave: false,
  saveUninitialized: false
}));
app.use(express.static(path.join(__dirname, '..', 'public')));

function requireAuth(req, res, next) {
  if (req.session.user) return next();
  res.status(401).json({ error: 'Giriş yapmalısınız' });
}
function requireAdmin(req, res, next) {
  if (req.session.user && req.session.user.role === 'admin') return next();
  res.status(403).json({ error: 'Yetkisiz erişim' });
}

// ---------- pages ----------
app.get('/', (req, res) => {
  if (!req.session.user) return res.redirect('/login.html');
  if (req.session.user.role === 'admin') return res.redirect('/admin.html');
  res.redirect('/panel.html');
});

// ---------- auth ----------
app.post('/api/register', (req, res) => {
  const { name, email, password } = req.body || {};
  if (!name || !email || !password)
    return res.status(400).json({ error: 'Tüm alanlar zorunludur' });
  const users = loadUsers();
  if (users.find(u => u.email === email))
    return res.status(400).json({ error: 'Bu e-posta zaten kayıtlı' });
  const user = {
    id: Date.now().toString(),
    name,
    email,
    password: bcrypt.hashSync(password, 10),
    role: users.length === 0 ? 'admin' : 'user', // first user = admin
    createdAt: new Date().toISOString()
  };
  users.push(user);
  saveUsers(users);
  req.session.user = { id: user.id, name, email, role: user.role };
  res.json({ message: 'Kayıt başarılı', role: user.role });
});

app.post('/api/login', (req, res) => {
  const { email, password } = req.body || {};
  const users = loadUsers();
  const user = users.find(u => u.email === email);
  if (!user || !bcrypt.compareSync(password, user.password))
    return res.status(401).json({ error: 'E-posta veya şifre hatalı' });
  req.session.user = { id: user.id, name: user.name, email, role: user.role };
  res.json({ message: 'Giriş başarılı', role: user.role });
});

app.post('/api/logout', (req, res) => {
  req.session.destroy(() => res.json({ message: 'Çıkış yapıldı' }));
});

app.get('/api/me', requireAuth, (req, res) => {
  res.json(req.session.user);
});

// ---------- user servers (own only) ----------
app.get('/api/servers', requireAuth, async (req, res) => {
  try {
    const containers = await docker.listContainers({ all: true });
    const mine = containers.filter(c =>
      c.Labels && c.Labels['mc-panel'] === 'true' &&
      c.Labels['owner'] === req.session.user.id);
    res.json(await Promise.all(mine.map(containerInfo)));
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'Sunucular alınamadı' });
  }
});

// create minecraft server (user)
app.post('/api/servers', requireAuth, async (req, res) => {
  try {
    const { name, version = '1.20.1', port = 25565, memory = '1024M' } = req.body || {};
    const image = `itzg/minecraft-server:${version === 'latest' ? 'latest' : version}`;
    await pullImageIfNeeded(image);
    const containerName = `mc-${(name || 'sunucu').replace(/[^a-zA-Z0-9]/g, '')}-${Date.now()}`;
    const volDir = path.join(DATA_DIR, containerName);
    fs.mkdirSync(volDir, { recursive: true });

    const container = await docker.createContainer({
      Image: image,
      name: containerName,
      Env: ['EULA=TRUE', `MEMORY=${memory}`, `TYPE=VANILLA`],
      HostConfig: {
        PortBindings: { '25565/tcp': [{ HostPort: String(port) }] },
        Binds: [`${volDir}:/data`]
      },
      Labels: { 'mc-panel': 'true', 'type': 'minecraft', 'owner': req.session.user.id }
    });
    await container.start();
    res.status(201).json({ id: container.id, name: containerName, message: 'Sunucu oluşturuldu' });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'Sunucu oluşturulamadı: ' + (e.reason || e.message) });
  }
});

// container actions (owner or admin)
async function ownsOrAdmin(req, id) {
  if (req.session.user.role === 'admin') return true;
  try {
    const info = await docker.getContainer(id).inspect();
    return info.Config.Labels && info.Config.Labels['owner'] === req.session.user.id;
  } catch { return false; }
}

app.post('/api/servers/:id/start', requireAuth, async (req, res) => {
  if (!(await ownsOrAdmin(req, req.params.id)))
    return res.status(403).json({ error: 'Yetkisiz' });
  try { await docker.getContainer(req.params.id).start(); res.json({ message: 'Başlatıldı' }); }
  catch (e) { res.status(500).json({ error: 'Başlatılamadı' }); }
});

app.post('/api/servers/:id/stop', requireAuth, async (req, res) => {
  if (!(await ownsOrAdmin(req, req.params.id)))
    return res.status(403).json({ error: 'Yetkisiz' });
  try { await docker.getContainer(req.params.id).stop(); res.json({ message: 'Durduruldu' }); }
  catch (e) { res.status(500).json({ error: 'Durdurulamadı' }); }
});

app.delete('/api/servers/:id', requireAuth, async (req, res) => {
  if (!(await ownsOrAdmin(req, req.params.id)))
    return res.status(403).json({ error: 'Yetkisiz' });
  try { await docker.getContainer(req.params.id).remove({ force: true }); res.json({ message: 'Silindi' }); }
  catch (e) { res.status(500).json({ error: 'Silinemedi' }); }
});

app.get('/api/servers/:id/logs', requireAuth, async (req, res) => {
  if (!(await ownsOrAdmin(req, req.params.id)))
    return res.status(403).json({ error: 'Yetkisiz' });
  try {
    const container = docker.getContainer(req.params.id);
    const buf = await container.logs({ stdout: true, stderr: true, tail: 200 });
    res.json({ logs: buf.toString('utf8') });
  } catch (e) {
    res.status(500).json({ error: 'Loglar alınamadı' });
  }
});

// ---------- user settings ----------
app.put('/api/me', requireAuth, (req, res) => {
  const { name, password } = req.body || {};
  const users = loadUsers();
  const user = users.find(u => u.id === req.session.user.id);
  if (!user) return res.status(404).json({ error: 'Kullanıcı bulunamadı' });
  if (name) user.name = name;
  if (password) user.password = bcrypt.hashSync(password, 10);
  saveUsers(users);
  req.session.user.name = user.name;
  res.json({ message: 'Ayarlar güncellendi' });
});

// ---------- ADMIN ----------
app.get('/api/admin/servers', requireAdmin, async (req, res) => {
  try {
    const containers = await docker.listContainers({ all: true });
    const mine = containers.filter(c => c.Labels && c.Labels['mc-panel'] === 'true' &&
      c.Labels['type'] !== 'node');
    res.json(await Promise.all(mine.map(containerInfo)));
  } catch (e) {
    res.status(500).json({ error: 'Sunucular alınamadı' });
  }
});

app.get('/api/admin/nodes', requireAdmin, async (req, res) => {
  try {
    const containers = await docker.listContainers({ all: true });
    const nodes = containers.filter(c => c.Labels && c.Labels['type'] === 'node');
    res.json(await Promise.all(nodes.map(containerInfo)));
  } catch (e) {
    res.status(500).json({ error: 'Node sunucuları alınamadı' });
  }
});

app.post('/api/admin/nodes', requireAdmin, async (req, res) => {
  try {
    const { name, image = 'node:20-alpine', port = 3000, command = 'node -v' } = req.body || {};
    await pullImageIfNeeded(image);
    const containerName = `node-${(name || 'app').replace(/[^a-zA-Z0-9]/g, '')}-${Date.now()}`;
    const container = await docker.createContainer({
      Image: image,
      name: containerName,
      Cmd: ['sh', '-c', command],
      HostConfig: { PortBindings: { [`${port}/tcp`]: [{ HostPort: String(port) }] } },
      Labels: { 'mc-panel': 'true', 'type': 'node', 'owner': 'admin' }
    });
    await container.start();
    res.status(201).json({ id: container.id, name: containerName, message: 'Node sunucusu oluşturuldu' });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'Node sunucusu oluşturulamadı: ' + (e.reason || e.message) });
  }
});

// user management (admin)
app.get('/api/admin/users', requireAdmin, (req, res) => {
  const users = loadUsers().map(({ password, ...u }) => u);
  res.json(users);
});

app.put('/api/admin/users/:id', requireAdmin, (req, res) => {
  const { name, role } = req.body || {};
  const users = loadUsers();
  const user = users.find(u => u.id === req.params.id);
  if (!user) return res.status(404).json({ error: 'Kullanıcı bulunamadı' });
  if (name) user.name = name;
  if (role && ['admin', 'user'].includes(role)) user.role = role;
  saveUsers(users);
  res.json({ message: 'Kullanıcı güncellendi' });
});

app.delete('/api/admin/users/:id', requireAdmin, (req, res) => {
  if (req.params.id === req.session.user.id)
    return res.status(400).json({ error: 'Kendinizi silemezsiniz' });
  let users = loadUsers();
  users = users.filter(u => u.id !== req.params.id);
  saveUsers(users);
  res.json({ message: 'Kullanıcı silindi' });
});

app.listen(PORT, () => console.log(`Panel çalışıyor: http://localhost:${PORT}`));
