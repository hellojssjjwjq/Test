const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const Docker = require('dockerode');
const path = require('path');
const fs = require('fs');

const app = express();
const docker = new Docker({ socketPath: '/var/run/docker.sock' });

app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

// Helper function to wait for container to be ready (optional)
async function waitForContainer(container, timeout = 30000) {
  const start = Date.now();
  while (Date.now() - start < timeout) {
    const info = await container.inspect();
    if (info.State.Running) {
      return true;
    }
    await new Promise(resolve => setTimeout(resolve, 1000));
  }
  return false;
}

// Routes
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Get all containers (with label for minecraft servers)
app.get('/api/servers', async (req, res) => {
  try {
    const containers = await docker.listContainers({ all: true });
    // Filter containers that have our label (e.g., "minecraft-server=true")
    const minecraftContainers = containers.filter(c => 
      c.Labels && c.Labels['minecraft-server'] === 'true'
    );
    // Get detailed info for each
    const servers = await Promise.all(
      minecraftContainers.map(async (c) => {
        const container = docker.getContainer(c.Id);
        const info = await container.inspect();
        return {
          id: c.Id,
          name: c.Names[0].replace(/^\//, ''),
          image: c.Image,
          status: info.State.Status,
          created: c.Created,
          ports: c.Ports,
          labels: c.Labels
        };
      })
    );
    res.json(servers);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Failed to fetch servers' });
  }
});

// Create a new Minecraft server container
app.post('/api/servers', async (req, res) => {
  try {
    const { version = 'latest', port = 25565, memory = '1024M' } = req.body;
    const containerName = `mc-server-${Date.now()}`;
    
    // Docker run options for itzg/minecraft-server
    const container = await docker.createContainer({
      Image: `itzg/minecraft-server:${version}`,
      name: containerName,
      Env: [
        `EULA=TRUE`,
        `MEMORY=${memory}`,
        `VERSION=${version}`
      ],
      HostConfig: {
        PortBindings: {
          '25565/tcp': [{ HostPort: `${port}` }]
        },
        Binds: [
          // Persist world data: ./data/<containerName>:/data
          `${path.join(__dirname, 'data', containerName)}:/data`
        ]
      },
      Labels: {
        'minecraft-server': 'true'
      }
    });

    await container.start();
    // Wait for container to be ready (optional)
    // await waitForContainer(container);

    res.status(201).json({ 
      id: container.Id, 
      name: containerName, 
      message: 'Minecraft server container created and started' 
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Failed to create server' });
  }
});

// Start a container
app.post('/api/servers/:id/start', async (req, res) => {
  try {
    const container = docker.getContainer(req.params.id);
    await container.start();
    res.json({ message: 'Server started' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Failed to start server' });
  }
});

// Stop a container
app.post('/api/servers/:id/stop', async (req, res) => {
  try {
    const container = docker.getContainer(req.params.id);
    await container.stop();
    res.json({ message: 'Server stopped' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Failed to stop server' });
  }
});

// Remove a container
app.delete('/api/servers/:id', async (req, res) => {
  try {
    const container = docker.getContainer(req.params.id);
    await container.remove({ force: true });
    res.json({ message: 'Server removed' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Failed to remove server' });
  }
});

// Get logs of a container
app.get('/api/servers/:id/logs', async (req, res) => {
  try {
    const container = docker.getContainer(req.params.id);
    const stream = await container.logs({
      stdout: true,
      stderr: true,
      timestamps: false,
      tail: 100
    });
    let data = '';
    stream.on('data', (chunk) => {
      data += chunk.toString();
    });
    stream.on('end', () => {
      res.send(`<pre>${data}</pre>`);
    });
    stream.on('error', (err) => {
      res.status(500).send('Error fetching logs');
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Failed to get logs' });
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});

// Ensure data directory exists
const dataDir = path.join(__dirname, 'data');
if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir, { recursive: true });
}