document.addEventListener('DOMContentLoaded', () => {
    const addServerBtn = document.getElementById('addServerBtn');
    const addServerModal = document.getElementById('addServerModal');
    const closeBtn = addServerModal.querySelector('.close');
    const serverForm = document.getElementById('serverForm');
    const serversContainer = document.getElementById('serversContainer');

    // Open modal
    addServerBtn.addEventListener('click', () => {
        addServerModal.style.display = 'flex';
    });

    // Close modal
    closeBtn.addEventListener('click', () => {
        addServerModal.style.display = 'none';
    });

    // Close modal when clicking outside
    window.addEventListener('click', (e) => {
        if (e.target === addServerModal) {
            addServerModal.style.display = 'none';
        }
    });

    // Handle form submission
    serverForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const serverName = document.getElementById('serverName').value.trim();
        const version = document.getElementById('version').value;
        const memory = document.getElementById('memory').value + 'M';
        const port = document.getElementById('port').value;

        if (!serverName) {
            alert('Lütfen bir sunucu adı girin.');
            return;
        }

        try {
            const response = await fetch('/api/servers', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    // Note: We are not using serverName for container name in backend, but we can send it as a label or env if needed.
                    // For simplicity, we'll just send the parameters the backend expects.
                    version,
                    port,
                    memory
                })
            });

            if (response.ok) {
                const result = await response.json();
                alert('Sunucu başarıyla oluşturuldu!');
                addServerModal.style.display = 'none';
                serverForm.reset();
                // Refresh server list
                fetchServers();
            } else {
                const error = await response.json();
                alert('Sunucu oluşturulamadı: ' + (error.error || 'Bilinmeyen hata'));
            }
        } catch (err) {
            console.error(err);
            alert('İstek sırasında bir hata oluştu.');
        }
    });

    // Fetch and display servers
    async function fetchServers() {
        try {
            const response = await fetch('/api/servers');
            if (response.ok) {
                const servers = await response.json();
                renderServers(servers);
            } else {
                console.error('Failed to fetch servers');
                serversContainer.innerHTML = '<p>Sunucular yüklenemedi.</p>';
            }
        } catch (err) {
            console.error(err);
            serversContainer.innerHTML = '<p>Bağlantı hatası.</p>';
        }
    }

    function renderServers(servers) {
        if (servers.length === 0) {
            serversContainer.innerHTML = '<p>Henüz sunucu yok.</p>';
            return;
        }

        serversContainer.innerHTML = ''; // Clear

        servers.forEach(server => {
            const card = document.createElement('div');
            card.className = 'server-card';
            card.innerHTML = `
                <h3>${server.name}</h3>
                <p><strong>Durum:</strong> <span class="status ${server.status}">${capitalizeFirstLetter(server.status)}</span></p>
                <p><strong>Görüntü:</strong> ${server.image}</p>
                <p><strong>Oluşturulma:</strong> ${new Date(server.created * 1000).toLocaleString()}</p>
                <div class="server-actions">
                    <button class="btn-primary start-btn" data-id="${server.id}">Başlat</button>
                    <button class="btn-success stop-btn" data-id="${server.id}" style="margin-left:10px;">Durdur</button>
                    <button class="btn-danger logs-btn" data-id="${server.id}" style="margin-left:10px;background:#6c757d;">Loglar</button>
                    <button class="btn-danger remove-btn" data-id="${server.id}" style="margin-left:10px;background:#dc3545;">Sil</button>
                </div>
            `;
            serversContainer.appendChild(card);
        });

        // Add event listeners to buttons
        document.querySelectorAll('.start-btn').forEach(btn => {
            btn.addEventListener('click', async (e) => {
                const id = e.target.dataset.id;
                await startServer(id);
            });
        });
        document.querySelectorAll('.stop-btn').forEach(btn => {
            btn.addEventListener('click', async (e) => {
                const id = e.target.dataset.id;
                await stopServer(id);
            });
        });
        document.querySelectorAll('.logs-btn').forEach(btn => {
            btn.addEventListener('click', async (e) => {
                const id = e.target.dataset.id;
                await showLogs(id);
            });
        });
        document.querySelectorAll('.remove-btn').forEach(btn => {
            btn.addEventListener('click', async (e) => {
                const id = e.target.dataset.id;
                if (confirm('Bu sunucuyu silmek istediğinizden emin misiniz?')) {
                    await removeServer(id);
                }
            });
        });
    }

    async function startServer(id) {
        try {
            const response = await fetch(`/api/servers/${id}/start`, { method: 'POST' });
            if (response.ok) {
                alert('Sunucu başlatıldı.');
                fetchServers();
            } else {
                const error = await response.json();
                alert('Sunucu başlatılamadı: ' + (error.error || 'Bilinmeyen hata'));
            }
        } catch (err) {
            console.error(err);
            alert('İstek sırasında bir hata oluştu.');
        }
    }

    async function stopServer(id) {
        try {
            const response = await fetch(`/api/servers/${id}/stop`, { method: 'POST' });
            if (response.ok) {
                alert('Sunucu durduruldu.');
                fetchServers();
            } else {
                const error = await response.json();
                alert('Sunucu durdurulamadı: ' + (error.error || 'Bilinmeyen hata'));
            }
        } catch (err) {
            console.error(err);
            alert('İstek sırasında bir hata oluştu.');
        }
    }

    async function removeServer(id) {
        try {
            const response = await fetch(`/api/servers/${id}`, { method: 'DELETE' });
            if (response.ok) {
                alert('Sunucu silindi.');
                fetchServers();
            } else {
                const error = await response.json();
                alert('Sunucu silinemedi: ' + (error.error || 'Bilinmeyen hata'));
            }
        } catch (err) {
            console.error(err);
            alert('İstek sırasında bir hata oluştu.');
        }
    }

    async function showLogs(id) {
        try {
            const response = await fetch(`/api/servers/${id}/logs`);
            if (response.ok) {
                const logsHtml = await response.text();
                // Create a modal to show logs
                const logModal = document.createElement('div');
                logModal.className = 'modal';
                logModal.innerHTML = `
                    <div class="modal-content">
                        <span class="close">&times;</span>
                        <h2>Sunucu Logları</h2>
                        ${logsHtml}
                    </div>
                `;
                document.body.appendChild(logModal);
                logModal.style.display = 'flex';
                const closeLogBtn = logModal.querySelector('.close');
                closeLogBtn.addEventListener('click', () => {
                    logModal.remove();
                });
                window.addEventListener('click', (e) => {
                    if (e.target === logModal) {
                        logModal.remove();
                    }
                });
            } else {
                const error = await response.json();
                alert('Loglar alınamadı: ' + (error.error || 'Bilinmeyen hata'));
            }
        } catch (err) {
            console.error(err);
            alert('İstek sırasında bir hata oluştu.');
        }
    }

    // Helper to capitalize first letter
    function capitalizeFirstLetter(string) {
        return string.charAt(0).toUpperCase() + string.slice(1);
    }

    // Initial fetch
    fetchServers();
});