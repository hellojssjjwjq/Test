// panel.html — kullanıcı paneli
// common.js'deki yardımcıları inline olarak tekrar tanımla (tek script etiketi kullanmak için)
async function api(url, options = {}) {
  const res = await fetch(url, { headers: { 'Content-Type': 'application/json' }, ...options });
  const data = await res.json().catch(() => ({}));
  if (res.status === 401) { window.location.href = '/login.html'; throw new Error('unauthorized'); }
  return { ok: res.ok, data };
}
function toast(msg, type = '') {
  const t = document.createElement('div');
  t.className = 'toast ' + type;
  t.textContent = msg;
  document.body.appendChild(t);
  setTimeout(() => t.remove(), 3000);
}
async function logout() {
  await fetch('/api/logout', { method: 'POST' });
  window.location.href = '/login.html';
}

let me = null;

// Menü geçişi
document.querySelectorAll('.nav-item').forEach(item => {
  item.addEventListener('click', () => {
    document.querySelectorAll('.nav-item').forEach(i => i.classList.remove('active'));
    item.classList.add('active');
    const page = item.dataset.page;
    document.getElementById('page-servers').style.display = page === 'servers' ? '' : 'none';
    document.getElementById('page-settings').style.display = page === 'settings' ? '' : 'none';
  });
});

// Kullanıcı bilgisi
(async () => {
  const { ok, data } = await api('/api/me');
  if (!ok) return;
  me = data;
  if (data.role === 'admin') { window.location.href = '/admin.html'; return; }
  document.getElementById('userName').textContent = '👤 ' + data.name;
  document.getElementById('sName').value = data.name;
  document.getElementById('sEmail').value = data.email;
  fetchServers();
})();

// Sunucu listesi
async function fetchServers() {
  const grid = document.getElementById('serversGrid');
  const { ok, data } = await api('/api/servers');
  if (!ok) { grid.innerHTML = '<p class="empty">Sunucular yüklenemedi.</p>'; return; }
  if (!data.length) { grid.innerHTML = '<p class="empty">Henüz sunucunuz yok. Yeni bir sunucu oluşturun! 🚀</p>'; return; }
  grid.innerHTML = '';
  data.forEach(s => {
    const card = document.createElement('div');
    card.className = 'card';
    card.innerHTML = `
      <h3>${s.name}</h3>
      <p><span class="badge ${s.status}">${s.status}</span></p>
      <p>İmaj: ${s.image}</p>
      <p>Oluşturulma: ${new Date(s.created * 1000).toLocaleString('tr-TR')}</p>
      <div class="actions">
        <button class="btn btn-sm btn-success" onclick="action('${s.id}','start')">▶ Başlat</button>
        <button class="btn btn-sm btn-stop" onclick="action('${s.id}','stop')">⏸ Durdur</button>
        <button class="btn btn-sm btn-ghost" onclick="showLogs('${s.id}')">📄 Loglar</button>
        <button class="btn btn-sm btn-danger" onclick="removeServer('${s.id}')">🗑 Sil</button>
      </div>`;
    grid.appendChild(card);
  });
}

async function action(id, act) {
  const { ok, data } = await api(`/api/servers/${id}/${act}`, { method: 'POST' });
  toast(ok ? data.message : (data.error || 'Hata'), ok ? 'success' : 'error');
  fetchServers();
}

async function removeServer(id) {
  if (!confirm('Bu sunucuyu silmek istediğinize emin misiniz?')) return;
  const { ok, data } = await api(`/api/servers/${id}`, { method: 'DELETE' });
  toast(ok ? data.message : (data.error || 'Hata'), ok ? 'success' : 'error');
  fetchServers();
}

async function showLogs(id) {
  const modal = document.getElementById('logModal');
  const content = document.getElementById('logContent');
  modal.classList.add('open');
  content.textContent = 'Yükleniyor...';
  const { ok, data } = await api(`/api/servers/${id}/logs`);
  content.textContent = ok ? (data.logs || '(log yok)') : (data.error || 'Hata');
}

// Modal
function openModal() { document.getElementById('createModal').classList.add('open'); }
function closeModal() { document.getElementById('createModal').classList.remove('open'); }

// Sunucu oluşturma
document.getElementById('createForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const btn = document.getElementById('createBtn');
  btn.disabled = true;
  btn.textContent = 'Oluşturuluyor... (imaj indirilebilir)';
  const body = {
    name: document.getElementById('cName').value.trim(),
    version: document.getElementById('cVersion').value,
    memory: document.getElementById('cMemory').value + 'M',
    port: parseInt(document.getElementById('cPort').value)
  };
  const { ok, data } = await api('/api/servers', { method: 'POST', body: JSON.stringify(body) });
  btn.disabled = false;
  btn.textContent = 'Oluştur';
  toast(ok ? data.message : (data.error || 'Hata'), ok ? 'success' : 'error');
  if (ok) { closeModal(); e.target.reset(); fetchServers(); }
});

// Ayarlar
document.getElementById('settingsForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const body = { name: document.getElementById('sName').value.trim() };
  const pw = document.getElementById('sPassword').value;
  if (pw) body.password = pw;
  const { ok, data } = await api('/api/me', { method: 'PUT', body: JSON.stringify(body) });
  toast(ok ? data.message : (data.error || 'Hata'), ok ? 'success' : 'error');
  if (ok && me) {
    me.name = body.name;
    document.getElementById('userName').textContent = '👤 ' + me.name;
    document.getElementById('sPassword').value = '';
  }
});
