// admin.html — admin paneli
async function api(url, options = {}) {
  const res = await fetch(url, { headers: { 'Content-Type': 'application/json' }, ...options });
  const data = await res.json().catch(() => ({}));
  if (res.status === 401) { window.location.href = '/login.html'; throw new Error('unauthorized'); }
  return { ok: res.ok, data };
}
function toast(msg, type = '') {
  const t = document.createElement('div');
  t.className = 'toast ' + type;
  t.textContent = msg;
  document.body.appendChild(t);
  setTimeout(() => t.remove(), 3000);
}
async function logout() {
  await fetch('/api/logout', { method: 'POST' });
  window.location.href = '/login.html';
}
function openModal(id) { document.getElementById(id).classList.add('open'); }
function closeModal(id) { document.getElementById(id).classList.remove('open'); }

// Menü geçişi
document.querySelectorAll('.nav-item').forEach(item => {
  item.addEventListener('click', () => {
    document.querySelectorAll('.nav-item').forEach(i => i.classList.remove('active'));
    item.classList.add('active');
    const page = item.dataset.page;
    document.getElementById('page-mc').style.display = page === 'mc' ? '' : 'none';
    document.getElementById('page-nodes').style.display = page === 'nodes' ? '' : 'none';
    document.getElementById('page-users').style.display = page === 'users' ? '' : 'none';
    if (page === 'mc') fetchMcServers();
    if (page === 'nodes') fetchNodes();
    if (page === 'users') fetchUsers();
  });
});

// Kullanıcı bilgisi + yetki kontrolü
(async () => {
  const { ok, data } = await api('/api/me');
  if (!ok) return;
  if (data.role !== 'admin') { window.location.href = '/panel.html'; return; }
  document.getElementById('userName').textContent = '👤 ' + data.name + ' (Admin)';
  fetchMcServers();
})();

// ---- Minecraft sunucuları ----
async function fetchMcServers() {
  const grid = document.getElementById('mcGrid');
  const { ok, data } = await api('/api/admin/servers');
  if (!ok) { grid.innerHTML = '<p class="empty">Sunucular yüklenemedi.</p>'; return; }
  if (!data.length) { grid.innerHTML = '<p class="empty">Henüz sunucu yok.</p>'; return; }
  grid.innerHTML = '';
  data.forEach(s => grid.appendChild(serverCard(s)));
}

// ---- Node sunucuları ----
async function fetchNodes() {
  const grid = document.getElementById('nodeGrid');
  const { ok, data } = await api('/api/admin/nodes');
  if (!ok) { grid.innerHTML = '<p class="empty">Yüklenemedi.</p>'; return; }
  if (!data.length) { grid.innerHTML = '<p class="empty">Henüz Node sunucusu yok.</p>'; return; }
  grid.innerHTML = '';
  data.forEach(s => grid.appendChild(serverCard(s)));
}

function serverCard(s) {
  const card = document.createElement('div');
  card.className = 'card';
  card.innerHTML = `
    <h3>${s.name}</h3>
    <p><span class="badge ${s.status}">${s.status}</span></p>
    <p>İmaj: ${s.image}</p>
    <p>Sahip: ${s.labels && s.labels.owner === 'admin' ? 'Admin' : (s.labels ? (s.labels.owner || '-') : '-')}</p>
    <p>Oluşturulma: ${new Date(s.created * 1000).toLocaleString('tr-TR')}</p>
    <div class="actions">
      <button class="btn btn-sm btn-success" onclick="action('${s.id}','start')">▶ Başlat</button>
      <button class="btn btn-sm btn-stop" onclick="action('${s.id}','stop')">⏸ Durdur</button>
      <button class="btn btn-sm btn-ghost" onclick="showLogs('${s.id}')">📄 Loglar</button>
      <button class="btn btn-sm btn-danger" onclick="removeServer('${s.id}')">🗑 Sil</button>
    </div>`;
  return card;
}

async function action(id, act) {
  const { ok, data } = await api(`/api/servers/${id}/${act}`, { method: 'POST' });
  toast(ok ? data.message : (data.error || 'Hata'), ok ? 'success' : 'error');
  refreshCurrent();
}
async function removeServer(id) {
  if (!confirm('Bu sunucuyu silmek istediğinize emin misiniz?')) return;
  const { ok, data } = await api(`/api/servers/${id}`, { method: 'DELETE' });
  toast(ok ? data.message : (data.error || 'Hata'), ok ? 'success' : 'error');
  refreshCurrent();
}
async function showLogs(id) {
  openModal('logModal');
  const content = document.getElementById('logContent');
  content.textContent = 'Yükleniyor...';
  const { ok, data } = await api(`/api/servers/${id}/logs`);
  content.textContent = ok ? (data.logs || '(log yok)') : (data.error || 'Hata');
}
function refreshCurrent() {
  const active = document.querySelector('.nav-item.active').dataset.page;
  if (active === 'mc') fetchMcServers();
  if (active === 'nodes') fetchNodes();
}

// ---- Sunucu oluşturma formları ----
document.getElementById('mcForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const btn = e.target.querySelector('button[type=submit]');
  btn.disabled = true; btn.textContent = 'Oluşturuluyor... (imaj indirilebilir)';
  const body = {
    name: document.getElementById('mcName').value.trim(),
    version: document.getElementById('mcVersion').value,
    memory: document.getElementById('mcMemory').value + 'M',
    port: parseInt(document.getElementById('mcPort').value)
  };
  // Admin de kullanıcı API'sini kullanabilir (owner = admin id)
  const { ok, data } = await api('/api/servers', { method: 'POST', body: JSON.stringify(body) });
  btn.disabled = false; btn.textContent = 'Oluştur';
  toast(ok ? data.message : (data.error || 'Hata'), ok ? 'success' : 'error');
  if (ok) { closeModal('mcModal'); e.target.reset(); fetchMcServers(); }
});

document.getElementById('nodeForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const btn = e.target.querySelector('button[type=submit]');
  btn.disabled = true; btn.textContent = 'Oluşturuluyor...';
  
  // textarea/quote temizliği
  let command = document.getElementById('nCommand').value;
  command = command.replace(/&quot;/g, '"').replace(/&amp;/g, '&');
  
  const body = {
    name: document.getElementById('nName').value.trim(),
    image: document.getElementById('nImage').value,
    command: command,
    port: parseInt(document.getElementById('nPort').value)
  };
  const { ok, data } = await api('/api/admin/nodes', { method: 'POST', body: JSON.stringify(body) });
  btn.disabled = false; btn.textContent = 'Oluştur';
  toast(ok ? data.message : (data.error || 'Hata'), ok ? 'success' : 'error');
  if (ok) { closeModal('nodeModal'); fetchNodes(); }
});

// ---- Kullanıcılar ----
async function fetchUsers() {
  const tbody = document.getElementById('usersTable');
  const { ok, data } = await api('/api/admin/users');
  if (!ok) { tbody.innerHTML = '<tr><td colspan="5">Yüklenemedi.</td></tr>'; return; }
  tbody.innerHTML = '';
  data.forEach(u => {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td>${u.name}</td>
      <td>${u.email}</td>
      <td><span class="badge ${u.role === 'admin' ? 'running' : 'exited'}">${u.role === 'admin' ? 'Admin' : 'Kullanıcı'}</span></td>
      <td>${new Date(u.createdAt).toLocaleDateString('tr-TR')}</td>
      <td>
        <button class="btn btn-sm btn-ghost" onclick="editUser('${u.id}','${u.name.replace(/'/g, "\\'")}','${u.role}')">✏️ Düzenle</button>
        <button class="btn btn-sm btn-danger" onclick="deleteUser('${u.id}')">🗑 Sil</button>
      </td>`;
    tbody.appendChild(tr);
  });
}

function editUser(id, name, role) {
  document.getElementById('uId').value = id;
  document.getElementById('uName').value = name;
  document.getElementById('uRole').value = role;
  openModal('userModal');
}

document.getElementById('userForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const id = document.getElementById('uId').value;
  const body = {
    name: document.getElementById('uName').value.trim(),
    role: document.getElementById('uRole').value
  };
  const { ok, data } = await api(`/api/admin/users/${id}`, { method: 'PUT', body: JSON.stringify(body) });
  toast(ok ? data.message : (data.error || 'Hata'), ok ? 'success' : 'error');
  if (ok) { closeModal('userModal'); fetchUsers(); }
});

async function deleteUser(id) {
  if (!confirm('Bu kullanıcıyı silmek istediğinize emin misiniz?')) return;
  const { ok, data } = await api(`/api/admin/users/${id}`, { method: 'DELETE' });
  toast(ok ? data.message : (data.error || 'Hata'), ok ? 'success' : 'error');
  fetchUsers();
}
