import zipfile
import os

def zip_directory(source_dir, output_zip):
    with zipfile.ZipFile(output_zip, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk(source_dir):
            for file in files:
                file_path = os.path.join(root, file)
                # Add file to zip with relative path
                arcname = os.path.relpath(file_path, start=source_dir)
                zipf.write(file_path, arcname)

if __name__ == '__main__':
    zip_directory('minecraft-panel', 'minecraft-panel.zip')